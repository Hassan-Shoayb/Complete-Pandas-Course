>>>>>> FTUApps.com <<<<<<

:: Instructions ::

Run & Enjoy

NOTE: Exclude the app via A/V program to avoid False positive infections, No harm by these infections, read more at torrent page description.

Visit https://ftuapps.com for more!

KMS & KMS 2038 & Digital & Online Activation Suite v9.5
==========================================================================================================================

This tool includes 4 different activation methods.

KMS Inject, Digital, KMS 2038 and Online activations.

While this script is being created, abbodi1406�s script is referenced. Thank him so much.

Some security programs will report infected files, that is false-positive due KMS emulating.
NOTE: Windivert and Digital Activation methods are virus free

If use this tools remove any other KMS solutions and temporary turn off AV security protection.

If RETAIL Office is installed on your computer, VOLUME license certificates will be installed automatically on activation process

$OEM$ Activation About:
3 methods are also $OEM$ activation support.
To preactivate the system during installation, copy $OEM$ folder to "sources" folder in the installation media (iso/usb)
$OEM$ activation method also enable the KMS task scheduling system during installation. (digital and KMS2038 activation method except) 

Virustotal results of the application exe and dll files:
          
Virustotal results of dll files of KMSInject method
x64 KMS.dll (23 September 2021)
https://www.virustotal.com/gui/file/bcde6b7bbafa2b4eeb6c75f051b5949d27b49b4030e376a7838ba84e4e103daf
          
x86 KMS.dll (23 September 2021)
https://www.virustotal.com/gui/file/c43ccfcc2f7ab3e2d229da6b1fb9715cc707991835108518cb0aa9a667ea15cc

A64 KMS.dll (23 September 2021)
https://www.virustotal.com/gui/file/24bf5b777254334c384e02ced455d21470163569d33ffebad36e54f6afd5059c

          
Virustotal results of exe and dll files of the Digital & KMS38 Activation method
gatherosstate.exe (15 September, 2019)
https://www.virustotal.com/gui/file/028c8fbe58f14753b946475de9f09a9c7a05fd62e81a1339614c9e138fc2a21d/detection

slc.dll (November 23, 2019)
https://www.virustotal.com/gui/file/e7eca8c7476df70ef525ae55a0d8ccc715f22a727165a05fd4c380032cf763a9

==========================================================================================================================

Activation Method      Support Products                                        Activation Period
--------------------------------------------------------------------------------------------------------------------------

Digital License        -  Windows 10 / 11                                      -  Permanent
KMS38 License          -  Windows 10 / 11 / Server                             -  Until 2038 years 
KMS License            -  Windows 7 (VL) 8 / 8.1 / 10 / 11 / Server / Office   -  180 day license (KMS Task Scheduling is required for a perpetual license) 
Online KMS License     -  Windows 7 (VL) 8 / 8.1 / 10 / 11 / Server / Office   -  180 day license (KMS Task Scheduling is required for a perpetual license, this option does not exist in the script) 

==========================================================================================================================

# SUPPORTED MICROSOFT PRODUCTS:

  Windows 7 (VL) / Windows 8 / 8.1 / 10 (ARM64) / 11 (ARM64)
  Windows Server 2008 / 2012 / 2012 R2 / 2016 / 2019 / 2022
  Office (VL) 2010 / 2013 / 2016 / 2019 / 2021
  
  
# UNSUPPORTED MICROSOFT PRODUCTS:

   * Office Retail (Supported if Volume License certificates are installed)
   * Windows 7 (Starter, HomeBasic, HomePremium, Ultimate)
   * Windows 10 (Cloud S, Professional Single Language)
   * Windows Server (Server Foundation, Storage Server, Home Server 2011)

==========================================================================================================================

# WHAT TO KNOW:

  * Run KMS Suite either on the desktop or in the root directory of any disk. Do not run through folders with long names 
    and folders inside the folder. 
    
  * If the RETAIL Office is installed on your computer, the activation query may not show any results.
  
  * During normal activation in the Inject method, Windows and Office can be activated separately, but in the KMS Task  
    Scheduling module and the $OEM$ Activation option Windows and Office are activated together.
	
  * If you get "No Instance(s) Available" error while using, close the script file and run it again.
  
  * Use the EXIT option from the menu options to close the script file.

==========================================================================================================================

# KNOWN BUGS:

If you find errors, report them on the topic in the TNCTR and Nsane Forums.

==========================================================================================================================

NOTE:

The WinDivert method is not included in version v9x because it is not running healthy since Windows 10 v1809 and later 
versions will not be included.

==========================================================================================================================

# Special Thanks

TNCTR Family  
Nsane Family  
abbodi1406
CODYQX4
qewlpal
s1ave77
cynecx
qad
Mouri_Naruto
WindowsAddict
mspaintmsi
BAU

==========================================================================================================================